var mathlib = require('./mathlib')
console.log(mathlib);
mathlib.add(1,2);
mathlib.multiply(3,5);
mathlib.square(6); 
mathlib.random_num(1,35);